Source code for applications in:

Beal, L., Park, J., Petersen, D., Warnick, S., Hedengren, J.D., Combined Model Predictive Control and Scheduling with Dominant Time Constant Compensation, 2017, doi: 10.1016/j.compchemeng.2017.04.024. 

http://www.sciencedirect.com/science/article/pii/S0098135417301874
