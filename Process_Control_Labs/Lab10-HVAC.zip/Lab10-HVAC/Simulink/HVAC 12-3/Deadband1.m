function y = Deadband1(u)

y = 1 + u;