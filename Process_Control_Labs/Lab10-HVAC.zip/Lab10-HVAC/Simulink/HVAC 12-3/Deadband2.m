function y = Deadband2(u)

y = 1 + u;