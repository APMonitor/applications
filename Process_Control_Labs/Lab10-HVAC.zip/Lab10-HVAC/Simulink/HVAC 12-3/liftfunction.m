function y = liftfunction(u)

y= u(1)/(u(1)+u(2));