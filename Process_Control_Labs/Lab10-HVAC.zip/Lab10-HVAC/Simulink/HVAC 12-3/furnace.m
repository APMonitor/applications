function y = furnace(u)

if (u(1) >= 0 && u(2) >= 0)
    
    y = 1;
else
    y = -1;
    
end
    
        