function y = SE(u)

y = u(1)*u(1) + u(2)*u(2);