function y = HVACeq1(u)

y(1)= u(2)*(1-u(1));