function y = HVACeq2(u)

y(1)= u(2)*(u(1));