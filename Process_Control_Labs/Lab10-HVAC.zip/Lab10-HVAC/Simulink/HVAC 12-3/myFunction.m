function y = myFunction(u)

y= 27*u(1)/(27*u(1)+27*u(2));

