close all; clear all; clc

addpath('apm')

s = 'http://byu.apmonitor.com';
a = 'hvac';

apm(s,a,'clear all');

% load the model file
apm_load(s,a,'hvac.apm');

% load the data file
%csv_load(s,a,'hvac_ctl_10.csv');
csv_load(s,a,'hvac_ctl_20.csv');

% define parameters as MVs
apm_info(s,a,'MV','lift');
apm_info(s,a,'MV','int_furnace');

% define variables as CVs
apm_info(s,a,'CV','t1');
apm_info(s,a,'CV','t2');

% 6 = control
apm_option(s,a,'nlc.imode',6);
apm_option(s,a,'nlc.reqctrlmode',3);

% how frequently the furnace can turn on / off
apm_option(s,a,'int_furnace.mv_step_hor',2);

% Solver
%  1 = APOPT, 2 = BPOPT, 3 = IPOPT
apm_option(s,a,'nlc.solver',1);

% Turn off time shift
apm_option(s,a,'nlc.time_shift',0);

% initialize the MPC
output = apm(s,a,'solve');
disp(output);

% Turn on degrees of freedom (MVs)
apm_option(s,a,'lift.status',1);
apm_option(s,a,'int_furnace.status',1);

% solve the MPC
output = apm(s,a,'solve');
disp(output);

% retrieve the solution
y = apm_sol(s,a); 
z = y.x;

figure(1)
subplot(3,1,1)
plot(z.time,z.t1,'r-')
hold on
plot(z.time,z.t2,'b--')
legend('T_1','T_2')
ylabel('Temperature (degF)')
title('Temperature Simulation')

subplot(3,1,2)
plot(z.time,z.v1,'r-')
hold on
plot(z.time,z.v2,'b--')
legend('V_1','V_2')
ylabel('Velocity (m^3/min)')

subplot(3,1,3)
plot(z.time,z.lift,'r:')
hold on
plot(z.time,z.int_furnace,'k-.','LineWidth',2)
axis([min(z.time) max(z.time) -0.1 1.1])
legend('Lift','Furnace (On/Off)')
xlabel('Time (min)')

