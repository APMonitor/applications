function dx = ROP_Model(t,x,u)

global ROP

WOB = u(1);
RPM = u(2)/(2*pi); % onverting rad/s into rounds per second
P_bit = u(3);
Error=u(4);

h=x(1);

a_1=3.91;
a_2=9.45e-5;
a_3=6.86e-5;
a_4=8.64e-5;
a_5=0.37;
a_6=2.23;
a_7=0.025;
a_8=0.67;

W_over_db_t=1.3;
p_pore=300; %bar
F_j=-1;
f_t_d=0.3;
d_b=9.875;


f_1=exp(a_1);
f_2=exp(a_2*(10000-h));
f_3=exp(a_3*h^0.69*(P_bit-p_pore));
f_4=exp(a_4*h*(P_bit-p_pore));
f_5=((WOB/d_b-W_over_db_t)/(4-W_over_db_t))^a_5;

if (WOB/d_b-W_over_db_t)/(4-W_over_db_t)<0
    f_5=0;
end

f_6=(RPM/60)^a_6;
f_7=exp(-a_7*f_t_d);
f_8=exp(F_j/1000)^a_8;


ROP=0.3/3600*f_1*f_2*f_3*f_4*f_5*f_6*f_7*f_8;


dh_dt=ROP;

dx=[dh_dt];
end