function [sys, x0, str, ts]=WOB_S(t,x,u,flag, WOB_Desired_0)

global ROP_2

switch flag
    case 0 %initialize
        str=[];
        ts=[0,0];
        s=simsizes;
        s.NumContStates=1;
        s.NumDiscStates=0;
        s.NumOutputs=1;
        s.NumInputs=1;
        s.DirFeedthrough=1;
        s.NumSampleTimes=1;
        sys=simsizes(s);
        
        x0=[WOB_Desired_0]; %Initial conditions
        
    case 1 %derivatives
        sys=WOB_Model(t,x,u);
        
    case 3 %output
                          
        sys(1)=x(1);
                                  
    case {2 4 9}
        
        sys=[];
        
    otherwise
        error(['unhandled flag=', num2str(flag)]);
end