function [sys, x0, str, ts]=ROP_S(t,x,u,flag, h_O)

global ROP
persistent initialize
switch flag
    case 0 %initialize
        str=[];
        ts=[0,0];
        s=simsizes;
        s.NumContStates=1;
        s.NumDiscStates=0;
        s.NumOutputs=2;
        s.NumInputs=4;
        s.DirFeedthrough=1;
        s.NumSampleTimes=1;
        sys=simsizes(s);
        
        x0=[h_O]; %Initial conditions
        
    case 1 %derivatives
        sys=ROP_Model(t,x,u);
        
    case 3 %output
        
         if isempty(initialize)
            ROP_Model(t,x,u);
            initialize=1;
        end 
                          
        sys(1)=ROP;
        sys(2)=x(1);
                          
    case {2 4 9}
        
        sys=[];
        
    otherwise
        error(['unhandled flag=', num2str(flag)]);
end