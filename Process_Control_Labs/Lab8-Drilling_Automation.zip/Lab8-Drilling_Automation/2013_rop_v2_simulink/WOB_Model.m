function dx = WOB_Model(t,x,u)

global bha

WOB_Desired=u(1);
WOB=x(1);

tau_p=1;
K_p=1;

d_WOB_dt=(K_p*WOB_Desired-WOB)/tau_p;


dx=d_WOB_dt;


end