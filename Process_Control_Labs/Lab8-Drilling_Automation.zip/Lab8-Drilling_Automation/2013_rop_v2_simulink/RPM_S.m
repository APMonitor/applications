function [sys, x0, str, ts]=RPM_S(t,x,u,flag, x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18, x_19, x_20, x_21, x_22, x_23, x_24, x_25, x_26, x_27, x_28, x_29, x_30, x_31, x_32, x_33, x_34, x_35, x_36, x_37, x_38, x_39, x_40, x_41, x_42, x_43, x_44, x_45, x_46, x_47, x_48, x_49, x_50, x_51, x_52, x_53, x_54, x_55, x_56, x_57, x_58, x_59, x_60, x_61, x_62, x_63, x_64, x_65, x_66, x_67, x_68, x_69, x_70, x_71, x_72, x_73, x_74, x_75, x_76, x_77, x_78, x_79, x_80, x_81, x_82, x_83, x_84, x_85, x_86)

     
global bha
persistent initialize
switch flag
    case 0 %initialize
        str=[];
        ts=[0,0];
        s=simsizes;
        s.NumContStates=86;
        s.NumDiscStates=0;
        s.NumOutputs=1;
        s.NumInputs=1;
        s.DirFeedthrough=1;
        s.NumSampleTimes=1;
        sys=simsizes(s);
        
     x0=[x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18, x_19, x_20, x_21, x_22, x_23 ...
     x_24, x_25, x_26, x_27, x_28, x_29, x_30, x_31, x_32, x_33, x_34, x_35, x_36, x_37, x_38, x_39, x_40, x_41, x_42, x_43, x_44, x_45, x_46, ...
     x_47, x_48, x_49, x_50, x_51, x_52, x_53, x_54, x_55, x_56, x_57, x_58, x_59, x_60, x_61, x_62, x_63, x_64, x_65, x_66, x_67, x_68, x_69, ...
     x_70, x_71, x_72, x_73, x_74, x_75, x_76, x_77, x_78, x_79, x_80, x_81, x_82, x_83, x_84, x_85, x_86]; %Initial conditions
        
    case 1 %derivatives
        sys=RPM_Model(t,x,u);
        
    case 3 %output
        
        if isempty(initialize)
            RPM_Model(t,x,u);
            initialize=1;
        end 
        sys(1)=bha;
                          
    case {2 4 9}
        
        sys=[];
        
    otherwise
        error(['unhandled flag=', num2str(flag)]);
end