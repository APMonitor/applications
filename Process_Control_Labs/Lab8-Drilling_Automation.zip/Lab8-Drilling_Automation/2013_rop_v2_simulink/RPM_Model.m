function dx = RPM_Model(t,x,u)

global bha

for i=1:43
v(i,1)=x(i);
end
for i=44:86
d(i,1)=x(i);
end
    
vtd = u(1);

n = 43;
 
ks=35950;
kb=204020;
js=3.2021;
jb=15.8480;
ds=0.0271;
db=0.0266;



bha = v(n,1);



     dv(1,1)= (ds*ks*(vtd-v(1,1))+ ks*d(1,1)- ds*ks*(v(1,1)-v(2,1)) - ks*d(2,1))/js;
     dv(2,1)= (ds*ks*(v(1,1)-v(2,1))+ ks*d(2,1) - ds*ks*(v(2,1)-v(3,1)) - ks*d(3,1))/js;
for i=4:43
     dv(i-1,1)= (ds*ks*(v(i-2,1)-v(i-1,1)) + ks*d(i-1,1) - ds*ks*(v(i-1,1)-v(i,1))- ks*d(i,1))/js; 
     dv(n,1) = ((db*kb*(v(i-1,1)-v(i,1))+kb*d(i,1))- 1764*(v(i,1)/sqrt(v(i,1)^2+0.2^2) + (1.5*0.2*v(i,1))/(v(i,1)^2+0.2^2))-(0.28*v(i,1))*(v(i,1)/31.4-1))/jb;
end	         
		
dd(1,1)   = vtd      - v(1,1);
for i=2:43
  
    dd(i,1) = v(i-1,1) - v(i,1);
end
    bha = v(n,1);
    
    if bha<0
        bha=0;
    end



dx=zeros(1,2*n);

for i=1:43
dx(1,i)=dv(i,1);
end
for i=44:86
dx(1,i)=dd(i-43,1);
end
if t>1
    kkk=0;
end
end