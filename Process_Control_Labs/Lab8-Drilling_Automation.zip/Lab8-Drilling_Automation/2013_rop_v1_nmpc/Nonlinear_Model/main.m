clear all; close all; clc

% load APM libraries
addpath('apm')

n=86;
ODEoptions = odeset;

x0=zeros(n,1);

ts = linspace(0,10,100);
uu = 10;

% solve drillstring model in MATLAB
[t,x] = ode15s('drillstring',ts,x0,ODEoptions,uu);  

% solve drillstring model in APM
z = apm_solve('drillstring');
y = z.x;

figure(1)
subplot(2,1,1)
plot(t,x(:,1:43))
ylabel('Rot Rate (rad/sec)')
legend('Top Drive','Section 1','Section 2', 'etc')

subplot(2,1,2)
plot(t,x(:,44:86))
ylabel('Accel (rad/sec^2)')
legend('Top Drive','Section 1','Section 2', 'etc')

figure(2)
subplot(2,1,1)
plot(t,x(:,43),'r-')
hold on
plot(y.time,y.v43,'b--')
legend('MATLAB','APMonitor')

subplot(2,1,2)
plot(t,x(:,86),'r-')
hold on
plot(y.time,y.d43,'b--')
legend('MATLAB','APMonitor')
