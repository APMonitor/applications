%------------------------------------------------------------------
%Input data to stick slip model
%------------------------------------------------------------------

%------------------------------------------------------------------
%Conversion factors and constants
%------------------------------------------------------------------
%clear all;
rpm = pi/30;                  % rpm -> rad/s
in = 0.0254;                  % in -> m
deg = pi/180;                 % deg -> rad
g = 9.8066;                   % acceleration of gravity (m/s2)
tonf = 1000*g;                % ton force (N)           

%------------------------------------------------------------------
%Operational data
%------------------------------------------------------------------
tsim = 60;                    % simulation time
tssOn = 30;                   % turning on SoftSpeed
ts = 0.2;                     % storage sampling rate
Oset = 7;% 66.84*rpm;               % intitial speed (rad/s)
Oincr = 40*rpm;               % increment oplc speed when SoftSpeed on
fb = 0.25;                    % feed-back factor
ff = 0*0.5;                   % feed-forward factor
%tfb = 25; tst = tfb+100;     % time for switching on torque feedback
tst = 20; tfb = tst+100;      % time for switching on Impedance control
%Tmax = 19000;
WOB = 10*tonf;                % weight on bit

%------------------------------------------------------------------
%String and well data
%------------------------------------------------------------------
mu = 0.2;                     % friction coefficient
Dbit = 8.5*in;                % bit diameter
muBit = 0.25;                 % bit torque friction coefficient
tss = 1.5;                   % stick slip period (s)

strData = [...                % string geometry data
    0 5.0 6.5  31;...		  % MD(m), OD(in) ODJ(in),m(kg/m)
 % 7300 5.0 6.5  31;...
  %7301 5.5 6.5  65;...
 %7400 5.5 6.5  65;...
 979 5.0 6.5  31;...
 980 6.5 6.5  150;...
 1204 6.5 6.5  150;...
];
sraw = strData(:,1)';         % raw depth data as a row vector (m)
rhoStr = 7850;                % density of steel (kg/m3)
rhoMud = 1500;                % density of mud (kg/m3)
b = 1-rhoMud/rhoStr;          % buoyancy factor
A = strData(:,4)'/rhoStr;     % cross section area (m2)
OD = strData(:,2)'*in;        % outer string diameter
ODJ = strData(:,3)'*in;       % outer joint diameter
a = 0.05;                     % relative length of joints
ID = sqrt((1-a)*OD.^2+a*ODJ.^2-4*A/pi);% inner diameter (m)
IpB = pi/32*(OD.^4-ID.^4);    % polar moment body (m4);
IpJ = pi/32*(ODJ.^4-ID.^4);   % polar moment joint (m4);
Ip = (1-a)*IpB+a*IpJ;         % effective polar moment of inertia (m)
E = 206*10^9;                 % Youngs modulus of elasticity (Pa)
nu = 0.3;                     % Poisson ratio
G = E/(2*(1+nu));             % shear modulus of elasticity (Pa)
GIp = G./((1-a)./IpB+a./IpJ); % torsional compliance (rad/(Nm)/m)

L = 1*28;                     % length per element (m)
Ltot = max(strData(:,1));     % total length of string (m)
n = round(Ltot/L);            % number of elements
s = (1:n)*max(sraw)/n;        % depth vector (m)
m = interp1(sraw,strData(:,4)',s); % mass vector (kg/m);
w = b*m*g;                    % weight vector (N)
J = interp1(sraw,Ip*rhoStr,s)*L;% inertia moment vector (kgm2)
S = interp1(sraw,GIp,s)/L;    % stiffness vector (Nm/rad)
D = 0.01*L+0*J;               % linear damping vector (Nms)
O1 = 2*150*rpm;               % transition speed
td = 0.02 +1*0.75*sqrt(J./S); % internal damping parameter (s)
rJ =interp1(sraw,ODJ/2,s);	  % contact(=joint) radius vector (m) 

wellData = [...               % well geometry 
    0   0  0;...		      % MD(m), inclination(deg) azimuth(deg)
  300   0  0;...
 1500  00  0;...              % Ullrigg U2
 10000  00  0;...
];
%wellData = dlmread('Well E-4 B T3 revp1.txt'); %read from file
sWell =  wellData(:,1)';      % measured depth data as a row vector (m)
inclWell = wellData(:,2)'*deg;% inclination row vector
azimWell = wellData(:,3)'*deg;% azimuth row vector
incl = interp1(sWell,inclWell,s); % inclination vector(rad)
azim = interp1(sWell,unwrap(azimWell),s); % azimuth vector(rad)
dincl= [0 diff(incl)];        % inclination difference vector (rad)
dazim = [0 diff(azim)];       % *** azimuth difference vector
%b = ones(1,5)/5; dazim = filtfilt(b,1,dazim); dincl = filtfilt(b,1,dincl);
dZ = L*cos(incl);             % vertical depth increment (m)
Z = cumsum(dZ);               % vertical position vector (m)
dR = L*sin(incl);             % vertical depth increment (m)
R = cumsum(dR);               % vertical position vector (m)
% figure(3);
% plot(R,-Z,'k','LineWidth',2);
% set(gca,'FontWeight','bold');
% title(['Well profile for a ' num2str(max(s)) ' m long drill string']);
% axis([-100 6000 -5000 0]);
% set(gca,'PlotBoxAspectRatio',[max(R) max(Z) 1],'YTick',[-5000:1000:0]);
% xlabel('Horizontal reach (m)');
% ylabel('Vertical depth (m)');
% return %set(gca,'DataAspectRatio',[1 1]
F = sum(w.*dZ)-cumsum(w.*dZ); % Tension force vector (N)
F = F -WOB;                   %*** subtract weight on bit
Fn1 = F.*dincl-L*w.*sin(incl);%*** normal force vector (N) up
Fn2 = F.*dazim.*sin(incl);    %*** azimuth component of contact force
Fn = sqrt(Fn1.^2 + Fn2.^2);   %*** total normal force   
Tf = mu*abs(Fn.*rJ);          % torque per element (Nm)
  Tbit = muBit*Dbit/3*WOB;    % bit torque
  Tf(n) = Tf(n) + Tbit;       % add bit torque 
T = sum(Tf)-cumsum(Tf);       % Accumulated torque vector (Nm)
Tsum = sum(Tf);
Tmax = 1.25*Tsum+6e3;         % Max torque (150% of expected mean torque)
twist = sum(T./S)-cumsum(T./S); % twist vector (rad)
%plot(s,Fn/100/L,'b',s,Fn1/100/L,'m',s,Fn2/100/L,'k',s,T/1000,'r'); 
%figure(2);plot(s,Fn/100/L,'b',s,T/1000,'r'); 
%grid; legend('contact force (kN/10m)','torque(kNm)',1);
%return
O0 = 0.2;                     % transition speed (rad/s)
p = 1.5;                      % start friction parameter

%------------------------------------------------------------------
%Shift matrices
%------------------------------------------------------------------
shift1 = zeros(n,n);
for i = 2:n 
   shift1(i-1,i) = 1; 
end
shift_1= shift1';
inputV = zeros(1,n);
inputV(1) = 1;


%
%------------------------------------------------------------------
%Top Drive data
%------------------------------------------------------------------
ng = 6.383;                   % gear ratio (low gear)
%ng = 4.002;                  % gear ratio (high gear)
Jm = 18.2;                    % motor inertia moment (kgm2)
Pm = 500;                     % P-factor of speed controller (Nms)
ti = 0.3;                     % integration time constant (s)
Jeff = 1.5*Jm*ng^2;           % effective inertia (kgm2)
P = Pm*ng^2;                  % Torsional top resistance (Nms)
tachoDelay = 0.05;            % total delay time (s)

%------------------------------------------------------------------
%Anti stick slip data
%------------------------------------------------------------------
tdelay = 0;                   % total delay time (s)ignored?
%tss = 4;                     % stick slip period (s)
wss = 2*pi/tss;
tf = tss/2/pi;                % filter time constant
zeta =sqrt(S(1)*J(1));        % torsional string impedance (Nms)

Pss = zeta/fb;                % opimal drive impedance
tss1 = tss/2/pi-0*tdelay;     % adjusted time constant
tis = Pss/Jeff*tss1^2;        % optimal integration constant