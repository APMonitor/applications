%clear all
% Steady state values xss and uss are needed
close all
global uss xss js jb ks kb ds db

%Values for the drill string
ks=35950;
kb=204020;
js=3.2021;
jb=15.8480;
ds=0.0271;
db=0.0266;
uss = 10;

% Scaled system Gramians and balancing

%Controllabilty Gramian
Wc = control_gramian('drillstring',[0 100 1],[1 86 1 2 1000], [0.1 0.5 1],0);
%Wc = control_gramian('model',[start time, ending time,
%sampleLength],[InputNumber p, StateNumber n, OutputNumber k, Orientation
%Number r and length q],[size],flag)

%Observabilty Gramian
Wo = observ_gramian('drillstring',[0 100 1],[1 86 1 2 1000], [0.1 0.5 1],[43],xss,0);
%Wo = observ_gramian('model',[start time, ending time,
%sampleLength],[InputNumber p, StateNumber n, OutputNumber k, Orientation
%Number r and length q],[size],[OutputIndex],steady state,flag)

%Balancing
[Trans, invTrans, Wcb3, Wob3, svd_Wcb3, svd_Wob3] = balancing(Wc,Wo,86) ;
save nonlinear_model_reduction_matrix Trans invTrans Wcb3 Wob3 svd_Wcb3 svd_Wob3

%Sigma values
Sigma=diag(Trans*Wc3*Trans')

