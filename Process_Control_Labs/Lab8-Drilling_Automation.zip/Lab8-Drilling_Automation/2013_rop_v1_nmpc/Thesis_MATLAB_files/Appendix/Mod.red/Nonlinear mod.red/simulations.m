
%clear all
close all

global uss xss ud invTrans Trans red_n n js jb ks kb ds db 

%Values for the drill string
ks=35950;
kb=204020;
js=3.2021;
jb=15.8480;
ds=0.0271;
db=0.0266;
uss = 10;

load nonlinear_model_reduction_matrix Trans invTrans Wcb3 Wob3 svd_Wcb3 svd_Wob3


% The reduced system is simulated with a step response and compared with the original system

% Set the input
cm = -0.5;
ud=1-cm; 
n = 86;
red_n = 4;

% Initial states
initvalue = ones(n,1);      

% Integrate the original system
[t, y] = ode15s('drillstring',[0:0.1:60], initvalue);
% Copy data for real system
y0(:,1) = xss(43)*y(:,43);
t0 = t;


 
% Initial states reduced
initvalue = Trans*ones(n,1);
    
% Integrate reduced system with 4 states
[t, y] = ode15s('drillstring_reduced',[0:0.1:60], initvalue);

% Get the correct measurement
y = (invTrans*y')';
y2 = xss(43)*y(:,43);
t2 = t;

% Plot the simulations
figure(1);
plot(t0,y0(:,1),'k-',t2,y2(:,1),'k--');
xlabel('Time [sec]');
ylabel('y');
title('');
full = strcat('Full-order system with 86 states');
red_3 = strcat('Reduced-order system with 4 states');

legend(full,red_3,0);
top = max([y0(:,1);y2(:,1)]);
bot = min([y0(:,1);y2(:,1)]);
dif = (top-bot)*0.25;
axis([0 60 (bot-dif) (top+dif)]);
grid;

