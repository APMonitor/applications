
subplot(2,1,1)
plot(simout1.time, simout1.signals.values,'DisplayName','simout1.signals.values','YDataSource','simout1.signals.values');figure(gcf)
grid
subplot(2,1,2)
plot(simout2.time, simout2.signals.values,'DisplayName','simout2.signals.values','YDataSource','simout2.signals.values');figure(gcf)
grid



