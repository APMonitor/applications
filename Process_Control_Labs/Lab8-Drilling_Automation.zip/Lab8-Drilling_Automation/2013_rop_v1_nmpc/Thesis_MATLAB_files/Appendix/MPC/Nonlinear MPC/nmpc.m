global uss xss ud invTrans Trans red_n n
   
%clear all
n=86;

OPToptions = optimset('MaxFunEvals',1000);

global red_n du utm1

hor = 4.5;  % Prediction horizon
h_c = 1.5;  % Samplestep "control"
h_s = 0.05; % Samplestep simulation 
TX=[];
XT=[];
XT4=[];
UU=[];
DUU=[];
UU2=[];
A=diag(ones(32,1));
B=[inf*ones(31,1);5];
deltau=[];
du=zeros(1,31);
utm1=10*ones(1,31);

initvalue=[];
initvalue3=[];

u0 = 10*ones(1,round(hor/h_c));

ti = 0:h_c:hor-h_c;    %Time where input changes
tu = 0:h_s:hor;        %Simulationsteps in the horizon
ODEoptions = odeset;

lb = 0*ones(1,round(hor/h_c));  %Lower bound input
ub = 20*ones(1,round(hor/h_c)); %Upper bound input


red_n = 4; %Number of reduced states 
for i = 1:50
  if isempty(initvalue);
      initvalue=(Trans*ones(n,1));
  else  
  initvalue=x_init(i,:)';
  end 
  
  if isempty(initvalue3);
      initvalue3=ones(n,1);
  else  
  initvalue3=x_init3(i,:)';
  end 
  
  if i < 51
  uu=10*ones(1,31);
  u=10*ones(1,31);
  
  else
 
  u = fmincon('objfun',u0,[],[],[],[],lb,ub,[],OPToptions,initvalue,hor,h_c,h_s);
  uu = samplehold(ti,u,tu);
  end
  
  
  %Makes deltau
  uu(1);
  utm1(1);
  deltau=uu(1)-utm1(1)
  
  if deltau > 0.2
      uu(1)=utm1(1)+0.2;
  end
  if deltau < -0.2
      uu(1)=utm1(1)-0.2;
  end
  utm1(1)=uu(1);
  
  
  %Reduced model
  [tx,xt] = ode15s('drillstring_reduced',[0 0.2],initvalue,ODEoptions,tu,uu);
  x_init(i+1,:) = xt(length(tx),:);
  %ode23(modell,tidsspenn,startverdier, )
  
  %Full-scale model
  [tx3,xt3] = ode15s('drillstring',[tx],initvalue3,ODEoptions,tu,uu);  
  %Update values
  x_init3(i+1,:) = xt3(length(tx3),:);
  
  
  %Plots
  if isempty(TX);
      TX=tx;
  else  
  TX=[TX;tx];
  end
  
  %Correct measurements
  xt2=xt;
  xt2 = (invTrans*xt2')';
  xt2(:,1)= xss(43)*xt2(:,43);
  
  if isempty(XT);
      XT=xt2(:,1);
  else  
  XT=[XT;xt2(:,1)];
  end
  
  xt4=xt3;
  xt4(:,1) = xss(43)*xt4(:,43);
  
  if isempty(XT4);
      XT4=xt4(:,1);
  else  
      XT4=[XT4;xt4(:,1)];
  end
  
  
if isempty(UU);
      UU=uu(1);
else 
      UU=[UU;uu(1)];
end
 

u0=u;
end
subplot(2,1,1)
plot(XT)
grid
subplot(2,1,2)
plot(XT4)
grid