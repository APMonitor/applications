function y = samplehold(xi,x,yi);

y = zeros(size(yi)); % Works only for vectors

j=1;

for i = 1:length(yi),
  if j< length(xi),
    if yi(i) < xi(j+1),
      y(i) = x(j);
    else
      j = j+1;
      y(i) = x(j); 
    end
  else
    y(i) = x(j);
  end
end
