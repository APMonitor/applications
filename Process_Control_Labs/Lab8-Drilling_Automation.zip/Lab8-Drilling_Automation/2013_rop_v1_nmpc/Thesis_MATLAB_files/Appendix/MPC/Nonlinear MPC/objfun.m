function val = objfun(u,initvalue,hor,h_c,h_s);

global uss xss ud invTrans Trans red_n n du utm1

ti = 0:h_c:hor-h_c;
len = hor/h_s+1;

tu = 0:h_s:hor;


uu = samplehold(ti,u,tu);

options = odeset;

[tx,xt] = ode15s('drillstring_reduced',tu,initvalue,options,tu,uu);


Q = 10;
R = 0;

%Gives the correct measurement
xt2=xt;
  xt2 = (invTrans*xt2')';
  xt2(:,1)= xss(43)*xt2(:,43);

val = 0;
for i = 1:len-2,
  val = val + h_s*(( xt2(i+1)-10)*Q*(xt2(i+1)-10)');% + du(i)*R*du(i)') ;
  xt2(i+1);
end;


