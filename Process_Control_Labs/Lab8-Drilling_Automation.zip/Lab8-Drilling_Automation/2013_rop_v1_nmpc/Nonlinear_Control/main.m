clear all; close all; clc

% load APM libraries
addpath('apm');

% Specify server and application names
s = 'http://xps.apmonitor.com';
a = 'drill';

% Clear everything from last run
apm(s,a,'clear all');

% Load model and horizon
apm_load(s,a,'drillstring.apm');
csv_load(s,a,'horizon.csv');

% Declare variable types
apm_info(s,a,'MV','vtd');
apm_info(s,a,'CV','bha');

% Tuning for top drive rotational rate
apm_option(s,a,'vtd.status',1);
apm_option(s,a,'vtd.dmax',5);
apm_option(s,a,'vtd.lower',0);
apm_option(s,a,'vtd.upper',20);

% Tuning for BHA rotational rate 
apm_option(s,a,'bha.status',1);
apm_option(s,a,'bha.sphi',10.2);
apm_option(s,a,'bha.splo',9.8);
apm_option(s,a,'bha.tau',0.5);
apm_option(s,a,'bha.tr_init',2);
apm_option(s,a,'bha.tr_open',40);

% Controller options
apm_option(s,a,'nlc.time_shift',0);
apm_option(s,a,'nlc.imode',6);
apm_option(s,a,'nlc.reqctrlmode',3);

% Simulate drillstring model in APM
apm_option(s,a,'nlc.coldstart',1);
output = apm(s,a,'solve');
disp(output);

% Optimize drillstring model in APM
apm_option(s,a,'nlc.coldstart',0);
output = apm(s,a,'solve');
disp(output);

% retrieve solution
z1 = apm_sol(s,a);
y1 = z1.x;

% compute PID solution
z2 = apm_solve('drillstring_pid');
y2 = z2.x;

figure(1)
subplot(3,1,1)
plot(y2.time,y2.bha,'r.-')
hold on
plot(y2.time,y2.sp,'g.-')
ylabel('Bit Rate (rad/sec)')
legend('PID','PID Target')

subplot(3,1,2)
plot(y1.time,y1.bhatr_hi,'k:')
hold on
plot(y1.time,y1.bha,'b--','LineWidth',2)
plot(y1.time,y1.bhatr_lo,'k:')
ylabel('Bit Rate (rad/sec)')
legend('NMPC High Range','NMPC','NMPC Low Range')

subplot(3,1,3)
plot(y2.time,y2.vtd,'r.-','LineWidth',2)
hold on
plot(y1.time,y1.vtd,'b-','LineWidth',2)
legend('PID','NMPC')
ylabel('Top Drive (rad/sec)')
xlabel('Time (sec)')



apm_web(s,a);