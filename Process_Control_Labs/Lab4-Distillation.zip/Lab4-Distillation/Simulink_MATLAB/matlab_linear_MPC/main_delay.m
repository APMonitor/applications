% Clear local variables and plots
clc; clear all; close all

% Add APM libraries to path for session
addpath('apm');

% Integrate model and return solution
z = apm_optimize('distill_delay');
y = z.x;

figure(1)

subplot(2,1,1)
plot(y.time,y.x_bottoms,'b-','LineWidth',3)
hold on
plot(y.time,y.x_distillate,'r--')
%axis([0 max(y.time) -1 1])

legend('Bottoms','Distillate')
ylabel('Composition')

subplot(2,1,2)
plot(y.time,y.reflux_ratio,'b-','LineWidth',3)
hold on
plot(y.time,y.f_bottoms,'r--','LineWidth',3)

legend('Reflux Ratio','F_{bot}')

xlabel('Time (min)')
ylabel('Value')

