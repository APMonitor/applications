clc; clear all; close all

addpath('apm')


%% simulate the distillation model with RR changes
copyfile('distill_rr.csv','distill.csv'); % use distill_rr.csv
y = apm_solve('distill');

% save the data for x[1] (Distillate) linear model regression (FOPDT)
% truncate the first 10 steps (getting to steady-state)
data = [y.x.time(11:end) y.x.rr(11:end) y.x.x1(11:end) y.x.x32(11:end)];
save -ascii data_rr.txt data


%% simulate the distillation model with FBOT changes
copyfile('distill_fbot.csv','distill.csv'); % use distill_fbot.csv
y = apm_solve('distill');

% save the data for x[32] (Bottoms) linear model regression (FOPDT)
% truncate the first 10 steps (getting to steady-state)
data = [y.x.time(11:end) y.x.fbot(11:end) y.x.x1(11:end) y.x.x32(11:end)];
save -ascii data_fbot.txt data


%% simulate the distillation model with x_Feed changes
copyfile('distill_xfeed.csv','distill.csv'); % use distill_fbot.csv
y = apm_solve('distill');

% save the data for x[32] (Bottoms) linear model regression (FOPDT)
% truncate the first 10 steps (getting to steady-state)
data = [y.x.time(11:end) y.x.x_feed(11:end) y.x.x1(11:end) y.x.x32(11:end)];
save -ascii data_xfeed.txt data