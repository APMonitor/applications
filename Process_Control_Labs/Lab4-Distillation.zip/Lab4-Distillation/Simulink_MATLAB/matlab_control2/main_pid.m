% Clear MATLAB
clear all
close all

% Load APM libraries
addpath('apm');

z = apm_solve('distill_pid');
y = z.x;

% plot
figure(1)
subplot(4,1,1)
plot(y.time,y.sp_x1,'r-')
hold on
plot(y.time,y.x1,'b--')

subplot(4,1,2)
plot(y.time,y.sp_x32,'r-')
hold on
plot(y.time,y.x32,'b--')

subplot(4,1,3)
plot(y.time,y.x_feed,'r-')

subplot(4,1,4)
plot(y.time,y.feed,'r-')
