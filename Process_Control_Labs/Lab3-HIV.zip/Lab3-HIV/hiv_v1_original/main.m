% Clear MATLAB
clear all
close all

% Include APM libraries
addpath('apm');

% ------------------------------------------------------------------
% APM Simulation
% ------------------------------------------------------------------

% Select Server
%server = 'http://apmonitor.com';
%server = 'http://byu.apmonitor.com';
server = 'http://xps.apmonitor.com';
%server = 'http://localhost';

% Application Name
app = 'virus';

% Clear previous application
apm(server,app,'clear all');

% Load model variables and equations
apm_load(server,app,'hiv.apm');

% Load data
csv_load(server,app,'horizon.csv');

% State variables (for display only)
apm_info(server,app,'SV','H');
apm_info(server,app,'SV','I');
apm_info(server,app,'SV','V');

% imode = 4, switch to dynamic simulation
apm_option(server,app,'nlc.imode',7);
% coldstart application (1=sec, 2=min, 3=hr, 4=day, 5=yr)
apm_option(server,app,'nlc.ctrl_units',4);
% nodes per time step (2-6)
apm_option(server,app,'nlc.nodes',3);

% Run APMonitor
apm(server,app,'solve')

% Open web-viewer
apm_web(server,app);

% Extract results
results = apm_sol(server,app);
names = results(1,:);
vals = cell2mat(results(2:end,:));

% time is the first column
t_apm = vals(:,1);

% search name list for 'H'
index = find(strcmpi('h',names));
h_apm = vals(:,index);

% search name list for 'I'
index = find(strcmpi('i',names));
i_apm = vals(:,index);

% search name list for 'V'
index = find(strcmpi('v',names));
v_apm = vals(:,index);

y_apm = [h_apm i_apm v_apm];

% ------------------------------------------------------------------
% ODE15s Simulation
% ------------------------------------------------------------------

% Time interval
time = 0:0.25:15;

% Initial condition
x0 = [1e6 0 1e2];

% Integrate with ODE15s
[t_ode15s,y_ode15s] = ode15s('virus_model',time,x0);

% ------------------------------------------------------------------
% Trend Results
% ------------------------------------------------------------------

figure(1);
semilogy(t_apm,y_apm,'-')
hold on
semilogy(t_ode15s,y_ode15s,'o')
xlabel('Time')
ylabel('States')
legend('APM - H','APM - I','APM - V','MAT - H','MAT - I','MAT - V')

% add some measurement noise to the virus
ym = log10(y_ode15s(:,3));
randn('seed',-1)
ym = ym + randn(size(ym))*0.5;
figure(2);
plot(t_ode15s,log10(y_ode15s(:,3)),'-b',t_ode15s,ym,'or')
xlabel('Time')
ylabel('log10 virus')
