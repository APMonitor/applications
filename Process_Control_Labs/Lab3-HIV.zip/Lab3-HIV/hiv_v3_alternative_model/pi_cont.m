% Clear MATLAB
clear all
close all

clear
clc

addpath('apm');

% Select which serever to use
server = 'http://xps.apmonitor.com';

% Application Name
app = ['virus_pid_' int2str((1000*rand()))];

% Clear previous application
apm(server,app,'clear all');

% load model variables and equations
apm_load(server,app,'pi_cont.apm');

% State variables (for display only)
apm_info(server,app,'F','s');
apm_info(server,app,'F','r');
apm_info(server,app,'F','T_max');
apm_info(server,app,'F','mu_T');
apm_info(server,app,'F','k_1a');
apm_info(server,app,'F','k_2');
apm_info(server,app,'F','mu_b');
apm_info(server,app,'F','mu_V');
apm_info(server,app,'F','N');
apm_info(server,app,'F','drug');
apm_info(server,app,'S','T_renamed');
apm_info(server,app,'S','T_1');
apm_info(server,app,'S','T_2');
apm_info(server,app,'S','k_1');
apm_info(server,app,'S','beta');
apm_info(server,app,'C','V');
apm_info(server,app,'C','T_tot');
apm_info(server,app,'C','LV');

data = [];
drug = [0];
virus = [0.001];
t_store = [0];
t = 'time';
ti = cellstr(t);
td = [ti];

%% This section has the set point and the tuning parameters
% Set point
sp = 10;
% Initial intergral value for the pi controller
I = 0;
% kc value for the pi controller
kc = -1000;
% tauI value for the pi controller
tauI = 2.5;
% Initial free virus concentration
V = 0.001;

%%
% number of iterations with time steps of 0.25 yrs, for a = 40 t = 10 yrs
a = 40;
dd = [0; 0.25];
csvwrite_with_headers('time.csv',dd,td)

%Load new CSV file
csv_load(server,app,'time.csv')

% imode = 7, switch to dynamic simulation (sequential simulation)
apm_option(server,app,'nlc.imode',4);
% nodes = 3, internal nodes in the collocation structure (2-6)
apm_option(server,app,'nlc.nodes',3);
% simulation step size for every 'solve' command
apm_option(server,app,'nlc.csv_read',1);
% estimated varialbe type (1=L1-norm, 2=Squared error norm)
apm_option(server,app,'nlc.ev_type',2);
% history horizon
apm_option(server,app,'nlc.hist_hor',0);
% coldstart application (1=sec, 2=min, 3=hr, 4=day, 5=yr)
apm_option(server,app,'nlc.ctrl_units',5);
% select solver
apm_option(server,app,'nlc.solver',1);
% max number of iterationts that the solver can do before returning an
% error
apm_option(server,app,'nlc.max_iter',100);

% This loop finds the drug amount needed by the use of a PI Controller with
% antiwindup
for n = 1:a
    % Run Apmonitor
    tic
    output = apm(server,app,'solve');
    t= toc;

    % Get values for the PI Controller
    V = apm_tag(server,app,'v.model');
    delta_t = 0.25;
    
    % PI controller with Antiwindup
    mu = 0; 
    drug1 = mu + kc * (sp - V) + (kc/tauI) * I;
    if drug1 < 0
        drug1 = 0;
        I = I;
    % the max amount of drug that can be delivered at any one time    
    elseif drug1 > 20000 
        drug1 = 20000;
    else
        I = I + (sp - V) * delta_t;
    end
    
    apm_meas(server,app,'drug',drug1);
    drug = [drug; drug1];
    virus = [virus; V];
    t_store = [t_store; t_store(end)+0.25];
    
    disp(['Time: ' num2str(t_store(n+1,1)) ' Drug: ' num2str(drug1) ' Virus: ' num2str(V)])
end

figure(1)
subplot(2,1,1)
plot(t_store,drug);
ylabel('drug')
legend('drug')
subplot(2,1,2)
plot(t_store,virus);
ylabel('virus')
xlabel('time (yr)')
legend('virus')
