clc; clear all; close all

% linearize the nonlinear HIV model and put it into state-space form
% once the model is in state space form with with command ss( ), it can
%  be converted to the Laplace domain with the command tf( ).
kr1 = 1e5;
kr2 = 0.1;
kr3 = 2e-7;
kr4 = 0.5;
kr5 = 5;
kr6 = 100;
kr7 = 1;
kr8 = .9;

% steady state values determined from solving 4 equations and 4 unknowns

% state space model is:

% d(x)/dt = A * x + B * u
%       y = C * x + D * u

% this model is obtained by linearizing each equation and putting the
%   linearized portion in the A and B matrices. The "C" matrix indicates
%   which value is measured (in this case, Virus).

% input (u)
av_in = 1750;

% states (x)
H = 9.99e5;    % healthy cells
V = 50;        % virus
I = 20;        % infected cells
Av = 348;      % antiviral count

%  $H = kr1 - kr2*H - kr3*H*V
%  $I = kr3*H*V - kr4*I
%  $V = -kr3*H*V - kr5*V + kr6*I - kr7*V*AV
%  $AV = av_in - kr7*V*AV - kr8*AV

A = [ (-kr2-kr3*V), 0,    (-kr3*H),               0       ;
      (kr3*V) ,   -kr4,  (kr3*H),                0       ;
      (-kr3*V),    kr6,  (-kr3*H-kr5-kr7*Av), -kr7*V     ;
       0,          0,     -kr7*Av,            (-kr7*V-kr8)];
   
B = [0;0;0;1];

C = [0 0 1 0];

D = [0];

% create the state-space model
sys = ss(A,B,C,D);

% convert to a transfer function
syst = tf(sys);
% display the transfer function
syst

% generate a step response for the new linear model
step(syst)