% Clear local variables and plots
clc; clear all; close all

% Add APM libraries to path for session
addpath('apm');

% Integrate model and return solution
z = apm_solve('hiv');

% Plot results
figure(1)
subplot(4,1,1)
plot(z.time,z.av_in)
ylabel('av_{in}')
legend('Anti-Viral Injection')
subplot(4,1,2)
plot(z.time,z.h,'r--')
ylabel('H')
legend('Healthy Cells')
subplot(4,1,3)
semilogy(z.time,z.i,'k--')
hold on
semilogy(z.time,z.v,'b-')
ylabel('I and V')
legend('Infected','Virus')
subplot(4,1,4)
plot(z.time,z.av,'r.')
legend('Anti-Viral')
ylabel('AV')
xlabel('Time (yr)')

figure(2)
subplot(3,1,1)
plot(z.time,z.sp,'r-')
hold on
plot(z.time,z.v,'b-.')
hold on
plot(z.time,z.e,'k--')
subplot(3,1,2)
plot(z.time,z.av_in,'r-')


