% Clear local variables and plots
clc; clear all; close all

% Add APM libraries to path for session
addpath('apm');

% Integrate model and return solution
z = apm_optimize('hiv')

% Plot results
figure(1)
subplot(4,1,1)
plot(z.time,z.av_in)
ylabel('av_{in}')
legend('Anti-Viral Injection')
subplot(4,1,2)
plot(z.time,z.h,'r--')
ylabel('H')
legend('Healthy Cells')
subplot(4,1,3)
plot(z.time,z.i,'k--')
hold on
plot(z.time,z.v,'b-')
ylabel('I and V')
legend('Infected','Virus')
subplot(4,1,4)
plot(z.time,z.av,'r.')
legend('Anti-Viral')
ylabel('AV')
xlabel('Time (yr)')

% Export data
data = [z.time(3:end) z.av_in(3:end) z.v(3:end)];
save -ascii data.txt data