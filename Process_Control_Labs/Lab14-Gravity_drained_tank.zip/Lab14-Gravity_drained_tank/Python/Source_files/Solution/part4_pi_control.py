import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

def tank(levels,t,pump,valve):
    h1 = max(0.0,levels[0])
    h2 = max(0.0,levels[1])
    c1 = 0.08 # inlet valve coefficient
    c2 = 0.04 # tank outlet coefficient
    dhdt1 = c1 * (1.0-valve) * pump - c2 * np.sqrt(h1)
    dhdt2 = c1 * valve * pump + c2 * np.sqrt(h1) - c2 * np.sqrt(h2)
    # overflow conditions
    if h1>=1.0 and dhdt1>0.0:
        dhdt1 = 0
    if h2>=1.0 and dhdt2>0.0:
        dhdt2 = 0
    dhdt = [dhdt1,dhdt2]
    return dhdt

# Initial conditions (levels)
h0 = [0.0,0.0]

# Time points to report the solution
tf = 500
t = np.linspace(0,tf,tf+1)
# Inputs that can be adjusted
# pump can operate between 0 and 1
pump = np.zeros((tf+1))
# valve = 0, directly into top tank
# valve = 1, directly into bottom tank
valve = 0.0 
# Record the solution
y = np.empty((tf+1,2))
y[0,:] = h0

# specify number of steps
ns = tf
delta_t = t[1]-t[0]
# storage for recording values
op = np.zeros(ns+1)  # controller output
pv = np.zeros(ns+1)  # process variable
e = np.zeros(ns+1)   # error
ie = np.zeros(ns+1)  # integral of the error
dpv = np.zeros(ns+1) # derivative of the pv
P = np.zeros(ns+1)   # proportional
I = np.zeros(ns+1)   # integral
D = np.zeros(ns+1)   # derivative
sp = np.zeros(ns+1)  # set point
sp[25:150] = 0.2
sp[150:300] = 0.1
sp[300:] = 0.5

# From doublet fitting
Kp = 0.835617333631
taup = 27.6604059962
thetap = 4.9998992667

# PID (starting point)
Kc = 1.0/Kp
tauI = taup
tauD = 0.0

# PID (tuning)
Kc = Kc * 0.5
tauI = tauI
tauD = 0.0

# Upper and Lower limits on OP
op_hi = 1.0
op_lo = 0.0

# loop through time steps    
for i in range(0,ns):
    e[i] = sp[i] - pv[i]
    if i >= 1:  # calculate starting on second cycle
        dpv[i] = (pv[i]-pv[i-1])/delta_t
        ie[i] = ie[i-1] + e[i] * delta_t
    P[i] = Kc * e[i]
    I[i] = Kc/tauI * ie[i]
    D[i] = - Kc * tauD * dpv[i]
    op[i] = op[0] + P[i] + I[i] + D[i]
    if op[i] > op_hi:  # check upper limit
        op[i] = op_hi
        ie[i] = ie[i] - e[i] * delta_t # anti-reset windup
    if op[i] < op_lo:  # check lower limit
        op[i] = op_lo
        ie[i] = ie[i] - e[i] # anti-reset windup
    pump[i] = op[i]
    # Specify the pump and valve
    inputs = (pump[i],valve)
    # Integrate the model
    h = odeint(tank,h0,[0,delta_t],inputs)
    # Record the result
    pv[i+1] = h[-1,1]
    # Reset the initial condition
    h0 = h[-1,:]
op[ns] = op[ns-1]
ie[ns] = ie[ns-1]
P[ns] = P[ns-1]
I[ns] = I[ns-1]
D[ns] = D[ns-1]

# plot results
plt.figure(1)

plt.subplot(5,1,1)
plt.plot(t,sp,'k-',linewidth=2)
plt.plot(t,pv,'b--',linewidth=3)
plt.legend(['Set Point (SP)','Process Variable (PV)'],loc='best')
plt.ylabel('Process')

plt.subplot(5,1,2)
plt.plot(t,op,'r--',linewidth=3,label='Controller Output (OP)')
plt.plot(t,P,'g:',linewidth=2,label='Proportional (Kc e(t))')
plt.plot(t,I,'b.-',linewidth=2,label='Integral (Kc/tauI * Int(e(t))')
plt.plot(t,D,'k-.',linewidth=2,label='Derivative (-Kc tauD d(PV)/dt)')
plt.legend(loc=4)
plt.ylabel('Output')

plt.subplot(5,1,3)
plt.plot(t,e,'g:',linewidth=3)
plt.legend(['Error'],loc='best')
plt.ylabel('Error')

plt.subplot(5,1,4)
plt.plot(t,ie,'b.-',linewidth=3)
plt.legend(['Integral of Error'],loc='best')
plt.ylabel('Int Error')

plt.subplot(5,1,5)
plt.plot(t,dpv,'k-.',linewidth=3)
plt.legend(['Derivative of PV'],loc='best')
plt.ylabel('d(PV)/dt')

plt.xlabel('Time')

plt.show()
