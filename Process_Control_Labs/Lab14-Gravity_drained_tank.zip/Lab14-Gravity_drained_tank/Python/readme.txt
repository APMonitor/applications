See:

Dynamic Modeling: http://apmonitor.com/pdc/index.php/Main/DynamicModeling
Process Control:  http://apmonitor.com/pdc/index.php/Main/LevelControl