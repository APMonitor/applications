function [Cs,Csw] = solubilitylowT(Temp,v)  % Temp is temperature, v is volume based ethanol percentage in solvent
% From Yang Yang at Purdue
% Aspirin Solubility from Lindenberg and other sources.

    TempS = [3 25 35 50];
    EthanolS = [100 90 75 60 45 25 0];
    [X,Y] = meshgrid(TempS, EthanolS);

    S = [100.3 237.9 378.4 648.4
        119.5 283.2 419.1 689.2 
        112.5 266.6 395.3 679.1
        78.6 186.2 304.8 570.8
        37.1 87.9 149.5 377.0
        6.8 16.2 32.9 101.6
	    0 0 0 0]; 
    % Solubility of 25-50 Celsius and 25%-100% ethanol are 
    % measured from Lindenberg paper; 
    % 100.3 is solubility in 100% ethanol at 3 Celsius provided 
    % by G. D. Maia, J. Chem. Eng. Data 2008, 53, 256-258; 
    % Solubility in pure antisolvent (water) is approximated as 0; 
    % Other solubility at 3 Celsius is approximated based on solubility 
    % at 25 Celsius and assuming the slope is the same as in 100% ethanol.
    
    rhoE = 0.789;  % density of ethanol g/cm3
    rhoW = 1.0;     % density of water  g/cm3

    CE = (v*rhoE)/(v*rhoE+(1-v)*rhoW); % CE is mass based ethanol percentage in solvent
    Csw = griddata(X,Y,S,Temp,CE*100,'v4'); 
    Cs   = Csw*1e-3;
     
     
    rho = v*rhoE+(1-v)*rhoW; % density of ethanol-water mixture
    Cs = Cs*rho;
     
end