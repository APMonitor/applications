function [sys,x0,str,ts,simStateCompliance] = sfuncrystal(t,x,u,flag)
%SFUNTMPL General MATLAB S-Function Template
%   With MATLAB S-functions, you can define you own ordinary differential
%   equations (ODEs), discrete system equations, and/or just about
%   any type of algorithm to be used within a Simulink block diagram.
%
%   The general form of an MATLAB S-function syntax is:
%       [SYS,X0,STR,TS,SIMSTATECOMPLIANCE] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   What is returned by SFUNC at a given point in time, T, depends on the
%   value of the FLAG, the current state vector, X, and the current
%   input vector, U.
%
%   FLAG   RESULT             DESCRIPTION
%   -----  ------             --------------------------------------------
%   0      [SIZES,X0,STR,TS]  Initialization, return system sizes in SYS,
%                             initial state in X0, state ordering strings
%                             in STR, and sample times in TS.
%   1      DX                 Return continuous state derivatives in SYS.
%   2      DS                 Update discrete states SYS = X(n+1)
%   3      Y                  Return outputs in SYS.
%   4      TNEXT              Return next time hit for variable step sample
%                             time in SYS.
%   5                         Reserved for future (root finding).
%   9      []                 Termination, perform any cleanup SYS=[].
%
%
%   The state vectors, X and X0 consists of continuous states followed
%   by discrete states.
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%   When SFUNC is called with FLAG = 0, the following information
%   should be returned:
%
%      SYS(1) = Number of continuous states.
%      SYS(2) = Number of discrete states.
%      SYS(3) = Number of outputs.
%      SYS(4) = Number of inputs.
%               Any of the first four elements in SYS can be specified
%               as -1 indicating that they are dynamically sized. The
%               actual length for all other flags will be equal to the
%               length of the input, U.
%      SYS(5) = Reserved for root finding. Must be zero.
%      SYS(6) = Direct feedthrough flag (1=yes, 0=no). The s-function
%               has direct feedthrough if U is used during the FLAG=3
%               call. Setting this to 0 is akin to making a promise that
%               U will not be used during FLAG=3. If you break the promise
%               then unpredictable results will occur.
%      SYS(7) = Number of sample times. This is the number of rows in TS.
%
%
%      X0     = Initial state conditions or [] if no states.
%
%      STR    = State ordering strings which is generally specified as [].
%
%      TS     = An m-by-2 matrix containing the sample time
%               (period, offset) information. Where m = number of sample
%               times. The ordering of the sample times must be:
%
%               TS = [0      0,      : Continuous sample time.
%                     0      1,      : Continuous, but fixed in minor step
%                                      sample time.
%                     PERIOD OFFSET, : Discrete sample time where
%                                      PERIOD > 0 & OFFSET < PERIOD.
%                     -2     0];     : Variable step discrete sample time
%                                      where FLAG=4 is used to get time of
%                                      next hit.
%
%               There can be more than one sample time providing
%               they are ordered such that they are monotonically
%               increasing. Only the needed sample times should be
%               specified in TS. When specifying more than one
%               sample time, you must check for sample hits explicitly by
%               seeing if
%                  abs(round((T-OFFSET)/PERIOD) - (T-OFFSET)/PERIOD)
%               is within a specified tolerance, generally 1e-8. This
%               tolerance is dependent upon your model's sampling times
%               and simulation time.
%
%               You can also specify that the sample time of the S-function
%               is inherited from the driving block. For functions which
%               change during minor steps, this is done by
%               specifying SYS(7) = 1 and TS = [-1 0]. For functions which
%               are held during minor steps, this is done by specifying
%               SYS(7) = 1 and TS = [-1 1].
%
%      SIMSTATECOMPLIANCE = Specifices how to handle this block when saving and
%                           restoring the complete simulation state of the
%                           model. The allowed values are: 'DefaultSimState',
%                           'HasNoSimState' or 'DisallowSimState'. If this value
%                           is not speficified, then the block's compliance with
%                           simState feature is set to 'UknownSimState'.


%   Copyright 1990-2010 The MathWorks, Inc.

%
% The following outlines the general structure of an S-function.
%
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 10;   % System has 10 states
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 12;   % Output contains 10 states plus size and yield
sizes.NumInputs      = 8;    % Two temperatures and two flow rates
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
% Initial conditions: no crystals, and fill tanks with feed
x0 = [zeros(6,1); 0.40; 0.40; 0.792; 0.792];

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)

n = length(x);
dxdt = zeros(n,1);

%%%%% Input parameters
c0 = u(1); % Concentrations [g/mL]
F0 = u(2); F1 = u(4); F2 = u(7);  % Flow rates [mL/min] 
T1 = u(3); T2 = u(6);  % Temperatures [deg C]
V1 = u(5); V2 = u(8);  % Volumes [mL]

%%%%% States
m01 = x(1); m11 = x(2); m21 = x(3);  % Stage 1 moments
m02 = x(4); m12 = x(5); m22 = x(6);  % Stage 2 moments
c1 = x(7); c2 = x(8);   % solute concentration [g/mL]
v1 = x(9); v2 = x(10);  % volume fraction of solvent

%%%%% Other parameters
% Feed stream properties
c0 = 0.40;      % solute concentration [g/mL]
v0 = 0.792;     % volumetric fraction of solvent
% Crystal properties
kv = pi/6;      % Shape factor
rhoc = 1.4;     % crystal density [g/cm3]
% Nucleation (Lindenberg eqn 14-16)
R = 8.314;      % Gas constant [J/mol/K]
kB1 = 1.15e21;  % [1/m3/s]
kB2 = 7.67e4;   % [J/mol]
kB3 = 0.16;     % unitless
% Growth (Lindenberg eqn 18-20)
kG1 = 3.21e-4;  % [m/s]
kG2 = 2.58e4;   % [J/mol] 
kG3 = 1.00;     % unitless

%%%%% Intermediate variables
% Residence time (eqn 5)
F1out = F0+F1;  F2out = F1out + F2;
tau1 = V1/F1out; tau2 = V2/F2out;
% dilution factor
alpha1 = V2/V1;
% Solubility
[c1star,c1starL] = solubilitylowT(T1,v1);   % Units of [g/mL],[g/kg]
[c2star,c2starL] = solubilitylowT(T2,v2);

% Supersaturation
S1 = c1/c1star;  S2 = c2/c2star;
% Nucleation (B) and growth (G) rates
gunit = 100*60;  % Convert growth rate to cm/min from m/s
bunit = 60/1e6;  % Convert nucleation rate to 1/mL/min from 1/m3/s
% Growth rate requires cstar in units of g-solute/kg-solvent
if (S1 >= 1)
    B1 = kB1*exp(-kB2/R/(T1+273))*exp(-kB3/(log(S1))^2)*bunit;
    G1 = kG1*exp(-kG2/R/(T1+273))*(c1starL*(S1-1))^kG3*gunit;
else
    B1 = -kB1*exp(-kB2/R/(T1+273))*exp(-kB3/(log(1/S1))^2*bunit);
    G1 = -kG1*exp(-kG2/R/(T1+273))*(c1starL*(1-S1))^kG3*gunit;
end
if (S2 >= 1)
    B2 = kB1*exp(-kB2/R/(T2+273))*exp(-kB3/(log(S2))^2)*bunit;
    G2 = kG1*exp(-kG2/R/(T2+273))*(c2starL*(S2-1))^kG3*gunit;
else
    B2 = -kB1*exp(-kB2/R/(T2+273))*exp(-kB3/(log(1/S2))^2)*bunit;
    G2 = -kG1*exp(-kG2/R/(T2+273))*(c2starL*(1-S2))^kG3*gunit;
end

%%%%% Define the differential equations
% Stage 1 moments (eqn 7,9)
dxdt(1) = -1/tau1*m01 + B1;
dxdt(2) = -1/tau1*m11 + G1*m01;
dxdt(3) = -1/tau1*m21 + 2*G1*m11;
% Stage 2 moments (eqn 8,10)
dxdt(4) = m01/alpha1/tau1 -1/tau2*m02 + B2;
dxdt(5) = m11/alpha1/tau1 -1/tau2*m12 + G2*m02;
dxdt(6) = m21/alpha1/tau1 -1/tau2*m22 + 2*G2*m12;
% Solute concentrations in each stage (eqn 11-12)
dxdt(7) = F0/V1*c0 - c1/tau1 - 3*kv*rhoc*G1*m21;
dxdt(8) = c1/alpha1/tau1 - c2/tau2 - 3*kv*rhoc*G2*m22;
% Volumetric fraction of solvent in each stage (eqn 13-14)
dxdt(9) = F0/V1*v0 - v1/tau1;
dxdt(10) = v1/alpha1/tau1 - v2/tau2;

sys = dxdt;

% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)

% Compute the outputs of crystal size Ln [cm] and yield Y
% Defined in eqns 20-21
if (abs(x(4)) < 1e-8)
    Ln = 1e-8;
else
    Ln = x(5)/x(4);
end
F2out = u(2)+u(4)+u(7);  % Solvent flow rate out of Stage 2
Y = 1-(x(8)*F2out)/(u(1)*u(2));

sys = [x; Ln; Y];

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
