close all 
clc

% Plot the outputs from the crystal sfunction
figure(1)
subplot(2,1,1)
plot(y.Time,y.Data(:,1))
ylabel('size [cm]')
grid on
subplot(2,1,2)
plot(y.Time,y.Data(:,2))
ylabel('yield Y')
xlabel('time [min]')
grid on

% Plot the states (but don't feed these back into your control loop)
figure(2)
subplot(2,2,1)
plot(x.Time,x.Data(:,1),x.Time,x.Data(:,4))  % Zeroth moments
ylabel('\mu_0 [1/mL]')
subplot(2,2,2)
plot(x.Time,x.Data(:,2),x.Time,x.Data(:,5))  % First moments
ylabel('\mu_1 [cm/mL]')
subplot(2,2,3)
plot(x.Time,x.Data(:,7),x.Time,x.Data(:,8))  % Concentrations
ylabel('c [g/mL]')
subplot(2,2,4)
plot(x.Time,x.Data(:,9),x.Time,x.Data(:,10)) % Volume fractions
ylabel('v')


