%-------------------------------------------------------------------------
%-------------------------------- PARAM.M --------------------------------
%-------------------------------------------------------------------------
P.g = 9.81;       %m/s^2
P.l1 = 0.85;     %m
P.l2 = 0.3048;   %m
P.m1 = 0.891;    %kg
P.m2 = 1;        %kg
P.d = 0.178;     %m
P.h = 0.65;      %m
P.r = 0.12;      %m
P.Jx = 0.0047;   %kg*m^2
P.Jy = 0.0014;   %kg*m^2
P.Jz = 0.0041;   %kg*m^2
P.km = 0.0546;   %N/PWM
P.Fe = P.g*(P.m1*P.l1 - P.m2*P.l2)/P.l1;

P.Ts = 0.01;

P.max_left_pwm = 100;
P.max_right_pwm = 100;
% ------------------------------------------------------------------------
%Control Variables for THETA
P.theta_b0 = P.l1/(P.m1*P.l1^2+P.m2*P.l2^2+P.Jy);
P.theta_a0 = 0;
P.theta_a1 = 0;
P.Fmax = P.km*(P.max_left_pwm + P.max_right_pwm);
P.Emax_theta = 30*pi/180; %Pick this value - Max theta step size.
P.theta_zeta = sqrt(2)/2; %Pick this value - Damping coefficient.
P.Kp_theta = (P.Fmax-P.Fe)/P.Emax_theta;
P.Omega_n_theta = sqrt(P.theta_a0 + P.theta_b0*P.Kp_theta);
P.Kd_theta = (2*P.theta_zeta*P.Omega_n_theta-P.theta_a1)/P.theta_b0;
% ------------------------------------------------------------------------
% LAB 6 - the students should be choosing the PHI and PSI gains in a
% different manner. I have done it this way to save time.
% ------------------------------------------------------------------------
%Control Variables for PHI
P.phi_b0 = 1/P.Jx;
P.phi_a0 = 0;
P.phi_a1 = 0;
P.Tau_max = P.max_left_pwm*P.d*P.km;
P.Tau_e = 0;
P.Emax_phi = 30*pi/180; %Pick this value - Max phi step size.
P.phi_zeta = sqrt(2)/2; %Pick this value - Damping coefficient.
P.Kp_phi = (P.Tau_max - P.Tau_e)/P.Emax_phi;
P.Omega_n_phi = sqrt(P.phi_a0+P.phi_b0*P.Kp_phi);
P.Kd_phi = (2*P.phi_zeta*P.Omega_n_phi-P.phi_a1)/P.phi_b0;
% ------------------------------------------------------------------------
%Control Variables for PSI
P.psi_b0 = (P.l1*P.Fe)/(P.m1*P.l1^2+P.m2*P.l2^2+P.Jz);
P.psi_a0 = 0;
P.psi_a1 = 0;
P.Emax_psi = 30*pi/180;%Pick this value - Max psi step size.
P.psi_zeta = sqrt(2)/2; %Pick this value - Damping coefficient.
P.Kp_psi = P.Emax_phi/P.Emax_psi;
P.Omega_n_psi = sqrt(P.psi_a0+P.psi_b0*P.Kp_psi);
P.Kd_psi = (2*P.psi_zeta*P.Omega_n_psi-P.psi_a1)/P.psi_b0;
% ------------------------------------------------------------------------
%Lab6 - Finding Integrator Gains
    P.tau = 1/(2*pi*30);    % 30 Hz cut-off
    %Longitude -----------------------------------------------------------
    P.a_lon = P.l1/(P.m1*P.l1^2+P.m2*P.l2^2+P.Jy);
    h_theta = tf([P.a_lon],[1 P.a_lon*P.Kd_theta P.a_lon*P.Kp_theta 0]);
    figure(3);clf;rlocus(h_theta); % Use this to pick the integrator gain
    hold on; rlocus(h_theta,1,'r^')
    sgrid(P.theta_zeta,P.Omega_n_theta)
    P.Ki_theta = 2.42;      % Chosen from root locus plot
    
    %Latitude
    % PHI ----------------------------------------------------------------
    h_phi = tf([1],[P.Jx P.Kd_phi P.Kp_phi 0]);
    figure(4);clf;rlocus(h_phi); % Use this to pick the integrator gain
    sgrid(P.phi_zeta,P.Omega_n_phi)
    P.Ki_phi = 0.187;
    % PSI ----------------------------------------------------------------
    P.a_lat = P.l1*P.Fe/(P.m1*P.l1^2+P.m2*P.l2^2+P.Jz);
    h_psi = tf([P.a_lat],[1 P.a_lat*P.Kd_psi P.a_lat*P.Kp_psi 0]);
    figure(5);clf;rlocus(h_psi); % Use this to pick the integrator gain
    sgrid(P.psi_zeta,P.Omega_n_psi)
    P.Ki_psi = 0.106;
% ------------------------------------------------------------------------