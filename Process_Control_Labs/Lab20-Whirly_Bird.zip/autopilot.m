function pwm_commands = autopilot(u,P)
    % Process Inputs
    theta_d = u(1);
    psi_d   = u(2);
    phi     = u(3);
    %phidot  = u(4);
    theta   = u(5);
    %thetadot= u(6);
    psi     = u(7);
    %psidot  = u(8);
    t       = u(9);
% ---------------------------------------------------------    
    persistent int_ph int_th int_ps
    persistent dif_ph dif_th dif_ps
    persistent err_ph_d1 err_th_d1 err_ps_d1
    persistent ph_d1 th_d1 ps_d1
    persistent fig1 fig2 fig3
    
% ---------------------------------------------------------    
    if t == 0 %zero all persistent variables
        int_ph  = 0; int_th  = 0; int_ps  = 0;
        dif_ph  = 0; dif_th  = 0; dif_ps  = 0;
        err_ph_d1  = 0; err_th_d1  = 0; err_ps_d1  = 0;
        ph_d1   = 0; th_d1   = 0; ps_d1   = 0;
    end
% feedforward pitch command
    F_ff = P.Fe*cos(theta_d);
%     F_ff = P.Fe*cos(theta);

% PID PITCH LOOP ------------------------------------------
	err_th = theta_d - theta;
    dif_th = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*dif_th+2/(2*P.tau+P.Ts)*(theta-th_d1);
    %int_th = int_th + (P.Ts/2)*(err_th + err_th_d1);      
    if abs(err_th) > 5*pi/180
        int_th = 0;
    else
        int_th = int_th +(P.Ts/2)*(err_th + err_th_d1);
    end
    F = P.Kp_theta * err_th + P.Ki_theta * int_th - P.Kd_theta * dif_th + F_ff;
% PID YAW LOOP --------------------------------------------
	err_ps = psi_d - psi;
    dif_ps = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*dif_ps+2/(2*P.tau+P.Ts)*(psi-ps_d1);
%     int_ps = int_ps + (P.Ts/2)*(err_ps + err_ps_d1);
    if abs(err_ps) > 5*pi/180
        int_ps = 0;
    else
        int_ps = int_ps +(P.Ts/2)*(err_ps + err_ps_d1);
    end
    phi_c = P.Kp_psi * err_ps + P.Ki_psi * int_ps - P.Kd_psi * dif_ps;
% PID ROLL LOOP -------------------------------------------
    err_ph  = phi_c - phi;
    dif_ph = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*dif_ph+2/(2*P.tau+P.Ts)*(phi-ph_d1);
%     int_ph = int_ph + (P.Ts/2)*(err_ph + err_ph_d1);
    if abs(err_ph) > 5*pi/180
        int_ph = 0;
    else
        int_ph = int_ph +(P.Ts/2)*(err_ph + err_ph_d1);
    end
     
    Tau = P.Kp_phi * err_ph + P.Ki_phi * int_ph - P.Kd_phi * dif_ph;
% ---------------------------------------------------------    
% Update Persistent Variables
    err_th_d1 = err_th; err_ps_d1 = err_ps; err_ph_d1 = err_ph;
    th_d1  = theta; ps_d1  = psi; ph_d1  = phi;
% ---------------------------------------------------------    
% Convert force and torque to PWM outputs
  u_left  = 1/2/P.km*(F + Tau/P.d);
  u_right = 1/2/P.km*(F - Tau/P.d);
  % ---------------------------------------------------------    
% Limit output
  if u_left > 100, u_left = 100;
  elseif u_left < 0, u_left = 0;
  end
  if u_right > 100, u_right = 100;
  elseif u_right < 0, u_right = 0;
  end
  pwm_commands = [u_left; u_right];        
end