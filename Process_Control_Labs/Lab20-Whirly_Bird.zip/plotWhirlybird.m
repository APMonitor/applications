function plotWhirlybird (uu,D_param)
    % process inputs to function    
    phi      = uu(1);           % roll angle         
    theta    = uu(3);           % pitch angle     
    psi      = uu(5);           % yaw angle     
    t        = uu(7);           % time
    
    persistent whirly_handle;   % figure handle for whirlybird
    persistent platform_handle; % figure handle for platform
    persistent rod_handle;      % figure handle for whirlybird rod
    persistent r_blade_handle;    % figure handle for whirlybird r_blades
    persistent l_blade_handle;    % figure handle for whirlybird l_blade

    if t == 0 % Some portions of the figure are only drawn once
        setup_view;
        whirly_handle   = drawPart(D_param.whirly_V,...
                                   D_param.whirly_F,...
                                   D_param.whirly_color,...
                                   [],phi,theta,psi);
        platform_handle = drawPart(D_param.plat_V,...
                                   D_param.plat_F,...
                                   D_param.plat_color,...
                                   [],  0,    0,psi);
        rod_handle      = drawPart(D_param.rod_V,...
                                   D_param.rod_F,...
                                   D_param.rod_color,...
                                   [],  0,theta,psi);
        
        r_blade_handle = draw_blade(D_param,[],phi,theta,psi,t);
        l_blade_handle = draw_blade(D_param,[],phi,theta,psi,-t);
        patch('Vertices', D_param.base_V, 'Faces',D_param.base_F,...
              'FaceVertexCData',D_param.base_color,...
              'FaceColor','flat','EraseMode', 'normal');
    else 
        drawPart(D_param.whirly_V,...
                 D_param.whirly_F,...
                 D_param.whirly_color,...
                 whirly_handle,phi,theta,psi);
        drawPart(D_param.plat_V,...
                 D_param.plat_F,...
                 D_param.plat_color,...
                 platform_handle,0,0,psi);
        drawPart(D_param.rod_V,...
                 D_param.rod_F,...
                 D_param.rod_color,...
                 rod_handle, 0,theta,psi);
        
        draw_blade(D_param, r_blade_handle,phi,theta,psi,4*t);
        draw_blade(D_param, l_blade_handle,phi,theta,psi,4*(-t));
        drawnow;
    end
end
%-------------------------------------------------------------------------
function handle = drawPart(XYZ,F,color,handle,phi,theta,psi)
    XYZ = rotateVert(XYZ, phi, theta, psi);
    % transform vertices from NED to XYZ (for matlab rendering)
    NED = [0, 1,  0; 1, 0,  0; 0, 0, -1;];
    XYZ = (NED*XYZ')';
    if isempty(handle),
        handle = patch('Vertices', XYZ, 'Faces',F,...
                       'FaceVertexCData',color,...
                       'FaceColor','flat',...
                       'EraseMode', 'normal');
    else
        set(handle,'Vertices',XYZ,'Faces',F);
    end
end
%-------------------------------------------------------------------------
function verticies=rotateVert( XYZ, phi, theta, psi)
  % define rotation matrix
  R_roll  = [1,        0,         0;...
             0, cos(phi), -sin(phi);...
             0, sin(phi), cos(phi)];
         
  R_pitch = [cos(theta), 0, sin(theta);...
                      0, 1,          0;...
            -sin(theta), 0, cos(theta);];
        
  R_yaw   = [cos(psi), -sin(psi), 0;...
             sin(psi),  cos(psi), 0;...
                    0,         0, 1;];
                
  verticies = (R_yaw*R_pitch*R_roll*XYZ')';  
end
%-------------------------------------------------------------------------
function handle = draw_blade(D_param,handle,phi,theta,psi,t)
    XYZ = rotateVert(D_param.blade_V,0,0, t);
    
    if t<0
        XYZ = XYZ + repmat([33.46,-7,0],12,1);
    else
        XYZ = XYZ + repmat([33.46, 7,0],12,1);
    end
    
    XYZ = rotateVert(XYZ, phi, theta, psi);
    NED = [0,1,0;1,0,0;0,0,-1;]; XYZ = (NED*XYZ')';
    
    if isempty(handle),
        handle = patch('Vertices', XYZ, 'Faces',D_param.blade_F,...
                       'FaceVertexCData',D_param.blade_color,...
                       'FaceColor','flat',...
                       'EraseMode', 'normal');
    else
        set(handle,'Vertices',XYZ,'Faces',D_param.blade_F);
    end
end
%-------------------------------------------------------------------------
function setup_view()
    figure(1), clf
    hold on
    title('Whirlybird')
    xlabel('East')
    ylabel('North')
    zlabel('-Down')
    view (32,47)    %set the view angle for the figure
    axis([-40,40,-40,40,-40,40]);
    grid on
end
%-------------------------------------------------------------------------
